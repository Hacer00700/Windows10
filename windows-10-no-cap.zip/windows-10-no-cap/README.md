# windows 10. no cap.

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hacer00700/pen/PoQLwRb](https://codepen.io/Hacer00700/pen/PoQLwRb).

